class Footballer:
    def __init__(self, name, age, position):
        self.name = name
        self.age = age
        self.position = position

    def display_info(self):
        print(f"Name: {self.name}")
        print(f"Age: {self.age}")
        print(f"Position: {self.position}")
    
    def train(self):
        print(f"{self.name} is training.")

class Defender(Footballer):
    def __init__(self, name, age, position, tackles, interceptions):
        super().__init__(name, age, position)
        self.tackles = tackles
        self.interceptions = interceptions

    def display_info(self):
        super().display_info()
        print(f"Tackles: {self.tackles}")
        print(f"Interceptions: {self.interceptions}")
    
    def defend(self):
        print(f"{self.name} is defending.")

class Goalkeeper(Footballer):
    def __init__(self, name, age, position, saves, clean_sheets):
        super().__init__(name, age, position)
        self.saves = saves
        self.clean_sheets = clean_sheets

    def display_info(self):
        super().display_info()
        print(f"Saves: {self.saves}")
        print(f"Clean Sheets: {self.clean_sheets}")
    
    def save_goal(self):
        print(f"{self.name} is saving a goal.")

class Forward(Footballer):
    def __init__(self, name, age, position, goals, assists):
        super().__init__(name, age, position)
        self.goals = goals
        self.assists = assists

    def display_info(self):
        super().display_info()
        print(f"Goals: {self.goals}")
        print(f"Assists: {self.assists}")
    
    def score_goal(self):
        print(f"{self.name} has scored a goal.")


footballer1 = Footballer("ali", 22, "Substitute")
footballer2 = Footballer("hasan", 24, "Reserve")
defender1 = Defender("hossein", 28, "Defender", 50, 20) 
defender2 = Defender("mohammade", 27, "Defender", 45, 18) 
goalkeeper1 = Goalkeeper("mahdi", 30, "Goalkeeper", 100, 15) 
forward1 = Forward("mehdi", 25, "Forward", 25, 10)
forward2 = Forward("milad", 23, "Forward", 22, 8)  
goalkeeper2 = Goalkeeper("keyvan", 32, "Goalkeeper", 120, 18)
players = [footballer1, footballer2, defender1, defender2, goalkeeper1,goalkeeper2, forward1, forward2]
for player in players:
    player.display_info()
    player.train()    
    if ( player==defender1 or player== defender2):
      player.defend() 
    if ( player==goalkeeper1 or player== goalkeeper2):
      player.save_goal()      
    if ( player==forward1 or player== forward2):
      player.score_goal()
    print()
    
