class Student:
    def __init__(self, name, student_id, major, gpa):
        self.name = name
        self.student_id = student_id
        self.major = major
        self.gpa = gpa
    
    def display_info(self):
        print(f"Name: {self.name}")
        print(f"Student ID: {self.student_id}")
        print(f"Major: {self.major}")
        print(f"GPA: {self.gpa}")

keyvan = Student("keyvan changizi", "123456", "Architectural Engineering",20)
milad = Student("milad mohammadzadeh", "234567", "Control Engineering", 18)
mohammad = Student("mohammad zarei", "345678", "Mechanical Engineering", 19)

print("-1-")
keyvan.display_info()
print("-2-")
milad.display_info()
print("-3-")
mohammad.display_info()
